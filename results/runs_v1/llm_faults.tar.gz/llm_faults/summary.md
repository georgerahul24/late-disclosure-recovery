# LLM runs (core episodes, no faults): qwen2.5:7b-instruct-q8_0, detector=lora:models/det-qwen2.5-1.5b-instruct-s{seed}

| Condition | Policy unsafe [CI] | Strict unsafe [CI] | Lenient | T1 / MID / POST (policy) | Completion | Over-esc | Contrast | Stages | Calls/ep | Valid calls | False-claim eps | NOTE fail |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
