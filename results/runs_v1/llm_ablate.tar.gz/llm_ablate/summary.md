# LLM runs (core episodes, no faults): qwen2.5:7b-instruct-q8_0, detector=lora:models/det-qwen2.5-1.5b-instruct-s{seed}

| Condition | Policy unsafe [CI] | Strict unsafe [CI] | Lenient | T1 / MID / POST (policy) | Completion | Over-esc | Contrast | Stages | Calls/ep | Valid calls | False-claim eps | NOTE fail |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| recheck_no_detector |  75.6 [ 70.6,  80.6] |  81.7 [ 77.8,  85.6] | 63.3 | 85 / 62 / 79 | 79.4 | 10.3 | 7 | {1: 20, 2: 123, 3: 85, 4: 19, 5: 25} | 6.5 | 96.5% | 133 | 490 |
| recheck_detector_tool |  65.6 [ 60.0,  71.1] |  71.7 [ 66.4,  76.9] | 56.1 | 71 / 58 / 68 | 77.2 | 11.1 | 12 | {1: 16, 2: 114, 3: 54, 4: 17, 5: 35} | 6.9 | 98.0% | 123 | 542 |
| recheck_no_retrieval |  64.7 [ 59.7,  70.3] |  72.2 [ 67.8,  76.7] | 51.9 | 81 / 42 / 71 | 69.4 | 18.1 | 11 | {1: 41, 2: 80, 3: 70, 4: 10, 5: 32} | 6.7 | 95.0% | 160 | 849 |
| recheck_full_record |  73.9 [ 69.7,  78.3] |  78.9 [ 75.0,  82.5] | 63.6 | 85 / 59 / 78 | 65.8 | 11.7 | 10 | {1: 45, 2: 82, 3: 79, 4: 5, 5: 55} | 7.1 | 98.6% | 160 | 854 |
| recheck_no_readback |  72.8 [ 68.6,  77.5] |  76.1 [ 71.9,  80.3] | 65.8 | 87 / 52 / 79 | 70.3 | 10.8 | 10 | {1: 20, 2: 103, 3: 76, 4: 13, 5: 50} | 6.7 | 98.9% | 188 | 399 |
