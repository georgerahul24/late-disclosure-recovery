# LLM runs (core episodes, no faults): qwen2.5:7b-instruct-q8_0, detector=lora:models/det-qwen2.5-1.5b-instruct-s{seed}

| Condition | Policy unsafe [CI] | Strict unsafe [CI] | Lenient | T1 / MID / POST (policy) | Completion | Over-esc | Contrast | Stages | Calls/ep | Valid calls | False-claim eps | NOTE fail |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| safety |  74.8 [ 69.1,  80.2] |  98.4 [ 97.5,  99.2] | 38.2 | 80 / 62 / 82 | 99.1 | 37.2 | 34 | {1: 364, 2: 236, 3: 991, 4: 9, 5: 16} | 6.2 | 93.9% | 95 | 3720 |
| plain_label |  86.3 [ 83.8,  88.6] |  94.5 [ 93.3,  95.9] | 71.8 | 94 / 68 / 97 | 94.0 | 13.1 | 11 | {1: 398, 2: 602, 3: 788, 4: 2, 5: 74} | 6.0 | 96.2% | 413 | 4407 |
| plain |  82.9 [ 78.7,  86.8] |  98.2 [ 97.4,  98.9] | 55.4 | 85 / 69 / 94 | 97.9 | 19.4 | 13 | {1: 467, 2: 343, 3: 958, 4: 4, 5: 19} | 6.1 | 95.4% | 97 | 4089 |
