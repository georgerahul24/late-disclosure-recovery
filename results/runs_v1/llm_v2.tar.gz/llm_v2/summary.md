# LLM runs (core episodes, no faults): qwen2.5:7b-instruct-q8_0, detector=lora:models/det-qwen2.5-1.5b-instruct-s{seed}

| Condition | Policy unsafe [CI] | Strict unsafe [CI] | Lenient | T1 / MID / POST (policy) | Completion | Over-esc | Contrast | Stages | Calls/ep | Valid calls | False-claim eps | NOTE fail |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| recheck_v2 |  65.7 [ 62.3,  68.9] |  69.9 [ 66.7,  73.0] | 59.1 | 84 / 52 / 61 | 73.6 | 16.2 | 16 | {1: 228, 2: 498, 3: 354, 4: 67, 5: 272} | 7.5 | 98.4% | 301 | 3486 |
