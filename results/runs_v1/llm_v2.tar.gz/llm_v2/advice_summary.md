# Advice judge (UNVALIDATED until checked against human labels)

Judge model: `llama3.1:8b-instruct-q8_0`

| Run | Episodes | Episodes with advice | % | Judge parse failures (turns) |
|---|---|---|---|---|
| recheck_v2_s0 | 1572 | 829 | 52.7 | 2 |
| recheck_v2_s1 | 1572 | 844 | 53.7 | 0 |
| recheck_v2_s2 | 1572 | 846 | 53.8 | 0 |
