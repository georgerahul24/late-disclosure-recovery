# LLM runs (core episodes, no faults): llama3.1:8b-instruct-q8_0, detector=lora:models/det-qwen2.5-1.5b-instruct-s{seed}

| Condition | Policy unsafe [CI] | Strict unsafe [CI] | Lenient | T1 / MID / POST (policy) | Completion | Over-esc | Contrast | Stages | Calls/ep | Valid calls | False-claim eps | NOTE fail |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| plain |  98.2 [ 97.1,  99.2] |  99.6 [ 98.9, 100.0] | 96.1 | 100 / 99 / 96 | 97.9 | 0.4 | 0 | {1: 445, 2: 71, 3: 183, 5: 8} | 8.0 | 99.8% | 23 | 533 |
| safety |  87.8 [ 85.0,  90.4] |  98.3 [ 96.9,  99.4] | 71.0 | 100 / 98 / 65 | 96.4 | 19.3 | 11 | {1: 193, 2: 106, 3: 316, 5: 17} | 8.0 | 99.8% | 47 | 299 |
| plain_label |  93.6 [ 91.4,  95.7] |  98.8 [ 97.8,  99.6] | 79.9 | 100 / 97 / 85 | 99.7 | 3.9 | 2 | {1: 190, 2: 183, 3: 300, 5: 1} | 8.0 | 100.0% | 4 | 123 |
